#include <REG51.H>
#ifndef _Sys_H_
#define _Sys_H_

#define uint8_t unsigned char 
#define uint16_t unsigned short int     
#define uint32_t unsigned int
    
#endif
